"use strict";
/*
 * Wazuh app - React component building the welcome screen of an agent.
 * version, OS, registration date, last keep alive.
 *
 * Copyright (C) 2015-2020 Wazuh, Inc.
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * Find more information about this on the LICENSE file.
 */
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    Object.defineProperty(o, k2, { enumerable: true, get: function() { return m[k]; } });
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || function (mod) {
    if (mod && mod.__esModule) return mod;
    var result = {};
    if (mod != null) for (var k in mod) if (k !== "default" && Object.hasOwnProperty.call(mod, k)) __createBinding(result, mod, k);
    __setModuleDefault(result, mod);
    return result;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.RequirementsDonnut = void 0;
const react_1 = __importStar(require("react"));
const d3 = __importStar(require("d3"));
const hooks_1 = require("./hooks");
exports.RequirementsDonnut = props => {
    const pieRef = react_1.useRef();
    const cache = react_1.useRef(props.data);
    const [ref, dms] = hooks_1.useChartDimensions({}, pieRef);
    const createPie = d3
        .pie()
        .value(d => d.doc_count)
        .sort(null);
    const createArc = d3
        .arc()
        .innerRadius((dms.width * 0.75) / 2)
        .outerRadius(dms.width * 0.95 / 2)
        .padAngle(0.015);
    const colors = props.colors;
    const format = d3.format(".2f");
    react_1.useEffect(() => {
        const data = createPie(props.data);
        const prevData = createPie(cache.current);
        const group = d3.select(pieRef.current);
        const groupWithData = group.selectAll("g.arc").data(data);
        groupWithData.exit().remove();
        const groupWithUpdate = groupWithData
            .enter()
            .append("g")
            .attr("class", "arc");
        const path = groupWithUpdate
            .append("path")
            .merge(groupWithData.select("path.arc"));
        const arcTween = (d, i) => {
            const interpolator = d3.interpolate(prevData[i], d);
            return t => createArc(interpolator(t));
        };
        path
            .attr("class", "arc")
            .attr("fill", (d, i) => colors[i])
            .transition()
            .attrTween("d", arcTween);
        cache.current = props.data;
    }, [props.data, dms]);
    return (react_1.default.createElement("svg", { width: dms.width, height: dms.width },
        react_1.default.createElement("g", { ref: pieRef, transform: `translate(${[
                dms.width / 2,
                dms.width / 2
            ].join(",")})` })));
};
