"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.keysOf = void 0;
function keysOf(obj) {
    return Object.keys(obj);
}
exports.keysOf = keysOf;
